<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InstaCampImages extends Model
{
    //
    protected $fillable = [
        'image_name','image_size','insta_camp_id'
    ];
}
