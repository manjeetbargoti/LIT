<!-- footer Box -->
		
<footer>
			<div class="container"> 
				<div class="row "> 
					<div class="col-md-12 col-lg-3 pr-5">
						<img src="<?php echo e(asset('front/dist/img/logo.png')); ?>" class="mb-3" alt="" />
						<p> Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs.</p>
						<p> Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs.</p>
					</div>
					
					<div class="col-md-12 col-lg-3 pr-5">
						<h5 class="h5"> Address: </h5>
						<address>
							<p> Dubai World Trade Center, 26th Floor, Office 57 </p>
						</address>
						
						<h5 class="h5"> Email: </h5>
						<p> partnership@itdxb.com </p>
						
						<h5 class="h5"> Follow: </h5>
						<ul class="social"> 
							<li> <a href="#"> <i class="fa fa-twitter"> </i> </a> </li>
							<li> <a href="#"> <i class="fa fa-facebook"> </i> </a> </li>
							<li> <a href="#"> <i class="fa fa-youtube"> </i> </a> </li>
						</ul>
					</div>
					
					<div class="col-md-12 col-lg-4">
						<h5 class="h5"> Instagram: </h5>
						<div class="instabx"> 
							<img src="<?php echo e(asset('front/dist/img/home/insta1.jpg')); ?>" class="img-fluid" />
							<img src="<?php echo e(asset('front/dist/img/home/insta2.jpg')); ?>" class="img-fluid" />
							<img src="<?php echo e(asset('front/dist/img/home/insta3.jpg')); ?>" class="img-fluid" />
							<img src="<?php echo e(asset('front/dist/img/home/insta4.jpg')); ?>" class="img-fluid" />
							<img src="<?php echo e(asset('front/dist/img/home/insta5.jpg')); ?>" class="img-fluid" />
							<img src="<?php echo e(asset('front/dist/img/home/insta6.jpg')); ?>" class="img-fluid" />
						</div>
					</div>
					
					<div class="col-md-12 col-lg-2">
						<h5 class="h5"> Useful Links: </h5>
						<ul class="ulinks"> 
							<li> <a href="#"> About us </a> </li>
							<li> <a href="#">CSR Market Place</a> </li>
							<li> <a href="#"> Success Story </a> </li>
							<li> <a href="#"> Contact Us </a> </li>
						</ul>
					</div>
					
					<div class="col-md-12 col-lg-12 btmfooter mt-5"> 
						<p> &copy; Copyright @ 2019 Lit </p>
						<ul class="ulinks"> 
							<li> <a href="#"> Privacy Policy  </a> </li>
							<li> <a href="#"> |  </a> </li>
							<li> <a href="#"> Terms Of Services</a> </li>
						</ul>
					</div>
				</div>
			</div>
		
		</footer><?php /**PATH D:\LIT[29_01_2020]\resources\views/layouts/front/footer.blade.php ENDPATH**/ ?>